
void box(int, int, int, int);
void line(int,int,int,int);
